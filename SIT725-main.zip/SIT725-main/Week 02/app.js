const counter = require("./myModule");



console.log(counter.getCount(5));