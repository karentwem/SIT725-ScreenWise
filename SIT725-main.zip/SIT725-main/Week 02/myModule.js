

const inc = (c) => c+=1;
const dec = () => --count;
const getCount = (c) => c+=1;

module.exports = {
    getCount
};